package ds_s1p1;

public interface FactoriaCarreraYBicicleta {
    public abstract Carrera crearCarrera(int num);
    public abstract Bicicleta crearBicicleta();
}
