package ds_s1p1;

public class CarreraMontana extends Carrera {
    public CarreraMontana (int num, FactoriaMontana fac){
        super(num, fac);
        porcentajeRetiradas = 0.2;
    }
}
