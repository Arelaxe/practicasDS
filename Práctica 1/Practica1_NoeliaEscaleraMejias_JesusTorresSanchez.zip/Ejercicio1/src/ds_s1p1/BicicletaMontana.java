package ds_s1p1;

public class BicicletaMontana extends Bicicleta {
    
    public BicicletaMontana(FactoriaMontana fac){
        super(fac);
    }
}
