package ds_s1p1;

public class CarreraCarretera extends Carrera {
    public CarreraCarretera (int num, FactoriaCarretera fac){
        super(num, fac);
        
        porcentajeRetiradas=0.1;
    }
}
