package ds_s1p1;

public class BicicletaCarretera extends Bicicleta {
    public BicicletaCarretera(FactoriaCarretera fac){
        super(fac);
    }
    
}
