package p1s4;

public interface Filtro {
    public abstract double ejecutar(double r, EstadoMotor e);
}
