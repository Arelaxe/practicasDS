#encoding: utf-8

module DS_P1S1_Ruby
  class PrototipoBicicletaYCarrera
    def initialize
    
    end
  end
end 
