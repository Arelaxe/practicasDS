
package p1s3;

/**
 *
 * @author jesus
 */
public enum ZonaGeografica {
    ZONA1, ZONA2, ZONA3, ZONA4, ZONA5
}
