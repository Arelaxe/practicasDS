package p2;

public enum EstadoMotor {
    ACELERANDO, FRENANDO, APAGADO, ENCENDIDO;
}