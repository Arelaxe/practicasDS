
package p2;


public enum EstadoSCACV {
    APAGADO, ACELERAR, MANTENER, REINICIAR
}
